import 'package:flutter/material.dart';
import 'package:date_picker_timeline/date_picker_timeline.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import 'package:todo_app/ui/widgets/k_button.dart';
import '/services/theme_services.dart';
import 'theme.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  DateTime _selectedDate = DateTime.now();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _appBar(),
      body: SafeArea(
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              _todayBar(),
              _dateBar(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _dateBar() {
    return Container(
      padding: const EdgeInsets.only(top: 20),
      child: DatePicker(
        DateTime.now().subtract(const Duration(days: 365)),
        height: 100,
        width: 60,
        initialSelectedDate: _selectedDate,
        selectionColor: primaryClr,
        selectedTextColor: whiteClr,
        dateTextStyle: dateTextStyle,
        dayTextStyle: dayTextStyle,
        monthTextStyle: monthTextStyle,
        daysCount: 500,
        onDateChange: (date) {
          _selectedDate = date;
        },
      ),
    );
  }

  Widget _todayBar() {
    return Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  DateFormat.yMMMMd().format(DateTime.now()),
                  style: subHeadingStyle,
                ),
                Text(
                  "Today",
                  style: headingStyle,
                )
              ],
            ),
          ),
          KButton(label: "Đơn mới  +", onTap: () => null),
        ],
      ),
    );
  }

  _appBar() {
    return AppBar(
      backgroundColor: context.theme.backgroundColor,
      elevation: 0,
      leading: GestureDetector(
        onTap: () {
          ThemeServices().switchTheme();
        },
        child: Icon(
          Get.isDarkMode ? Icons.wb_sunny_outlined : Icons.nightlight_round,
          size: 20,
          color: Get.isDarkMode ? Colors.white : Colors.black,
        ),
      ),
      centerTitle: true,
      title: Text(
        "Phòng khám Đậu Đậu",
        style: TextStyle(
          color: Get.isDarkMode ? whiteClr : darkGreyClr,
        ),
      ),
    );
  }
}
