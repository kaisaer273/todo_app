import 'package:flutter/material.dart';
import 'package:todo_app/ui/theme.dart';

class KButton extends StatelessWidget {
  final String label;
  final Function()? onTap;
  const KButton({super.key, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 20),
          decoration: BoxDecoration(
            color: primaryClr,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Center(
            child: Text(
              label,
              style: const TextStyle(
                color: whiteClr,
                fontSize: 16,
              ),
            ),
          ),
        ));
  }
}
